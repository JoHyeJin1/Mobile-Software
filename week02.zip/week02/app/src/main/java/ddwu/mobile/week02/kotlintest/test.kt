package ddwu.mobile.week02.kotlintest

fun main(){
    println("Hello World!!!")
}